<template>
    <img src="/icons/money_icon.svg" alt="Icon Name">
</template>

